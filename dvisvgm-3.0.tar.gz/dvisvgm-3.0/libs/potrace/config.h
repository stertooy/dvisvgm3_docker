#ifndef CONFIG_H
#define CONFIG_H
#define VERSION "1.16"
#define HAVE_INTTYPES_H 1
#endif
