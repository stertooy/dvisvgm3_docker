/* Declarations for data tables */

extern const int amspua[], cns14pua[];
extern const char (*SaveTablesPref[]);
