#ifndef WOFF2_WOFF2_VERSION_H_
#define WOFF2_WOFF2_VERSION_H_

namespace woff2 {
constexpr const int version = 0x010002;
}

#endif
