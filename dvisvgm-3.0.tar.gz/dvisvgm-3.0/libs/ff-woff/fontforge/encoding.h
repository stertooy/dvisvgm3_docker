#ifndef _ENCODING_H
#define _ENCODING_H

extern void EncodingFree(Encoding *item);
#endif
